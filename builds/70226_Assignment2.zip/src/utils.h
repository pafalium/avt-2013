//utils.h

#ifndef __UTILS_H__
#define __UTILS_H__

extern const float PI_CONSTANT;
float deg2Rad(float degrees);

#endif