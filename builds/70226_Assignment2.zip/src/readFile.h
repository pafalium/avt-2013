//readFile.h

#ifndef __READ_FILE_H__
#define __READ_FILE_H__

#include <string>

std::string readFromFile(const std::string &filePath);

#endif