
#include "utils.h"

const float PI_CONSTANT = 3.14159265359;
float deg2Rad(float degrees)
{
	return (degrees / 180.0) * PI_CONSTANT;
}