//matrices_tests.h

#ifndef __MATRICES_TESTS_H__
#define __MATRICES_TESTS_H__

void testMatrices();

#endif