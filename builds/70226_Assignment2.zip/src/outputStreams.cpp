//outputStreams.cpp

#include "outputStreams.h"

namespace OutStreams {
	std::ostream &ShaderLog = std::clog;
}